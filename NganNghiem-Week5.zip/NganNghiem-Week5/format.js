function format_name(first,last){

  first = first.trim();
  last = last.trim();

  
  if (first === "" || last === "") {
    return "";
  }

  first = first[0].toUpperCase() + first.slice(1).toLowerCase();
  last = last[0].toUpperCase() + last.slice(1).toLowerCase();

  return last + ", " + first;
}

module.exports = format_name;
