const divide = require("./divide");


describe("divide(a, b)", () => {
  test("divides two positive numbers", () => {
    expect(divide(4, 2)).toBe(2);
  });

  test("divides a positive by a negative number", () => {
    expect(divide(4, -2)).toBe(-2);
  });

  test("divides two negative numbers", () => {
    expect(divide(-4, -2)).toBe(2);
  });

  test("divides floats correctly", () => {
    expect(divide(0.3, 0.1)).toBeCloseTo(3);
  });

  test("throws an error when dividing by zero", () => {
    expect(() => divide(2, 0)).toThrow("Cannot divide by zero");
  });
});
