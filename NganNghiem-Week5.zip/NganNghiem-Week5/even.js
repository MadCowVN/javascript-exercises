function get_even_numbers(arr){
  return arr.filter(n => n % 2 === 0);
}

module.exports = get_even_numbers;
