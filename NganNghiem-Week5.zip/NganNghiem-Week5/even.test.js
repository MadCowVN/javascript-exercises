const get_even = require("./even");

test("mixed list", () => {
  expect(get_even([1,2,3,4])).toEqual([2,4]);
});

test("all odd", () => {
  expect(get_even([1,3,5])).toEqual([]);
});

test("empty list", () => {
  expect(get_even([])).toEqual([]);
});
