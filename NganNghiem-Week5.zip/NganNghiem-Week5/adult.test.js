const is_adult = require("./adult");

test("18 is adult", () => {
  expect(is_adult(18)).toBe(true);
});

test("17 not adult", () => {
  expect(is_adult(17)).toBe(false);
});

test("older adult", () => {
  expect(is_adult(30)).toBe(true);
});
