const format = require("./format");

test("formats normal names", () => {
  expect(format("John","Smith")).toBe("Smith, John");
});

test("removes extra spaces", () => {
  expect(format(" John "," Smith ")).toBe("Smith, John");
});

test("fixes casing", () => {
  expect(format("joHN","sMiTh")).toBe("Smith, John");
});
