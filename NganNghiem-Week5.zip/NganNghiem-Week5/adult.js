function is_adult(age){
  return age >= 18;
}

module.exports = is_adult;
