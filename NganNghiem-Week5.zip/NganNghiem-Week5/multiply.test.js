const multiply = require("./multiply");

test("multiply positives", () => {
  expect(multiply(2,3)).toBe(6);
});

test("multiply with zero", () => {
  expect(multiply(5,0)).toBe(0);
});

test("multiply negative", () => {
  expect(multiply(-2,3)).toBe(-6);
});
